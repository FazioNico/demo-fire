export const environment = {
  firebase: {
    projectId: 'demo2020-75757',
    appId: '1:517554055042:web:7936b4c9e0d9ac8d85519b',
    databaseURL: 'https://demo2020-75757.firebaseio.com',
    storageBucket: 'demo2020-75757.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyCXb3cJLnXLLN903GX43OHP4i71fA03LXs',
    authDomain: 'demo2020-75757.firebaseapp.com',
    messagingSenderId: '517554055042',
  },
  databaseCollection: 'nomades-24'
};