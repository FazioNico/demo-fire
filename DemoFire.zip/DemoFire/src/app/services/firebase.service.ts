import { Inject, Injectable } from '@angular/core';
import { Firestore, collectionData, query } from '@angular/fire/firestore';
import { collection, doc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  constructor(
    private readonly _fireStore: Firestore,
    @Inject('DB_NAME') private readonly _databaseName: string
  ) { }

  loadData() {
    const refCollection = collection(this._fireStore, this._databaseName);
    const q = query(refCollection);
    const data = collectionData(q, {idField: 'id'});
    return data;
  }

  async addData(data: {title: string;}) {
    console.log('preparing save data...');
    const docRef = doc(this._fireStore, this._databaseName + '/' + Date.now());
    await setDoc(docRef, data);
    console.log('done!');
  }

  async updateData(data: {title: string; id: string;}) {
    const docRef = doc(this._fireStore, this._databaseName + '/' + data.id);
    await updateDoc(docRef, data);
  }

  async deleteData(data: {id: string}) {
    const docRef = doc(this._fireStore, `${this._databaseName}/${data.id}`);
    await deleteDoc(docRef);
  }
}
