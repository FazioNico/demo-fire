import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { FirebaseService } from './services/firebase.service';
import { Auth, GoogleAuthProvider, UserCredential, authState, signInWithPopup, signOut } from '@angular/fire/auth';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'DemoFire';
  data$!: Observable<any>;
  userValue!: string;
  userCreds!: UserCredential;
  currentUser$ = authState(this._auth as any);

  constructor(
    private readonly _fireStoreService: FirebaseService,
    private readonly _auth: Auth
  ) {
    this.data$ = this._fireStoreService.loadData();
  }

  private async _signinWithGoogle() {
    const provider = new GoogleAuthProvider();
    const userCreds = await signInWithPopup(this._auth, provider)
    this.userCreds = userCreds;
  }

  private async _signout() {
    await signOut(this._auth);
  }

  async actions(type: string, payload?: any) {
    switch (true) {
      case type === 'add':
        this._fireStoreService.addData({title: this.userValue});
        this.userValue = '';
        break;
      case type === 'update':
        const text = prompt('write new text.') || 'empty text';
        this._fireStoreService.updateData({title: text, id: payload.id});
        break;
      case type === 'delete':
        this._fireStoreService.deleteData(payload);
        break;
      case type === 'signin':
        this._signinWithGoogle();
        break;
      case type === 'signout':
        this._signout();
        break;
      default:
        break;
    }
  }

}
